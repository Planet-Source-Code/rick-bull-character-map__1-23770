Character Map:
I wrote this quite a while ago and thought (for some reason) that I would upload it now. There are probably better ways to do things, but I am self taught so tough luck!

To use the Character map you must have included 'Microsoft Windows Common Controls 5.0 (SP2)' in the controls tab on the Components Window.
To do this Click the 'Project' menu then 'Components' and scroll down until you find 'Microsoft Windows Common Controls 5.0 (SP2)' and check it. Click OK and then load the Character Map form.
If you can't find 'Microsoft Windows Common Controls 5.0 (SP2)' you don't have it installed. The form should still work but the status bar will just be a picture box.

There are some options at the beginning of the code under the general section. These are constants that you can change which will affect the way the CMap works. I think that they are all commented, so read them and play about with them.

Oh yeah, you could place this form in your templates folder and it will appear in the Add Form window. That's what I did anyway..

If I nicked anyone's code I'm very sorry.

So long Suckers!

Rick Bull

E-mail: rickbull@rickmusic.co.uk
Web: http://www.rickmusic.co.uk